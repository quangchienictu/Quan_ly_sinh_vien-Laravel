<?php $__env->startSection('title', 'Môn học'); ?>
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid">
        <h1 class="mt-4">Danh sách </h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Khoa</li>
        </ol>
        
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-table mr-1"></i>DataTable</div>
            <div class="card-body">
                <div class="table-responsive">
                   <!--   <a style="float: right;margin: 0px 20px;" class="btn btn-primary" href="" ><i class="fas fa-plus"></i>ADD</a> -->
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="text-align: center;">
                        <thead>
                            <tr>
                                <th>STT</th>
                                <th>Mã Khoa</th>
                                <th>Tên Khoa</th>
                                <th>Số lượng lớp</th>
                                <th>Số lượng SV</th>
                                <th>Xoá</th>
                                <th>Sửa</th>

                            </tr>
                        </thead>

                        <tbody>
                         <?php
                             $x =1;
                         ?>
                         <?php $__currentLoopData = $khoa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                            <td><?php echo e($x); ?></td>
                            <td><?php echo e($value->maKhoa); ?></td>
                            <td ><?php echo e($value->tenKhoa); ?></td>
                             <td><?php echo e($value->lop->count()); ?></td>
                              <td><?php echo e($value->sinhvien->count()); ?></td>
                            <td><button class="btn btn-danger" onclick="return xoa('<?php echo e(route('khoa.delete',['maKhoa'=>$value->maKhoa])); ?>')"><i class="fas fa-trash-alt"></i>Delete</button></td>
                             <td> <a  class="btn btn-success" href="<?php echo e(route('khoa.edit',['maKhoa'=>$value->maKhoa])); ?> " ><i class="fa fa-edit"></i>Edit</a></td>
                        </tr>
                        <?php
                          $x++;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QLSV_Laravel\resources\views/admin/khoa/danhsach.blade.php ENDPATH**/ ?>