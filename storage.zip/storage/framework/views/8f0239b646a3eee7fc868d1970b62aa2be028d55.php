<?php $__env->startSection('title', 'Thêm khoa'); ?>
<?php $__env->startSection('content'); ?>
<main>

  <div class="container-fluid">
    <h1 class="mt-4">Sửa điểm </h1>
    <div class="container">
      <?php if(count($errors)>0): ?>
          <script type="text/javascript">
            Swal.fire({
                  icon: 'error',
                  title: 'Lỗi ...',
                  text:'<?php echo e($errors->first()); ?>',
                })
          </script>
       <?php endif; ?>
       <?php if(session('thongbao')): ?>
            <script type="text/javascript">
                  Swal.fire(
                    'Thành công !',
                    '<?php echo e(session('thongbao')); ?>',
                    'success'
                  )
                </script>


            <?php endif; ?>
       

         
      <form action="diem/sua/<?php echo e($diem->id); ?>" class="needs-validation" method="post" novalidate>
        <?php echo csrf_field(); ?>
   
        
          
         <div class="form-group">
          <label for="pwd">Tên môn học :</label>
          <input type="text" class="form-control" id="pwd" value="<?php echo e($diem->monhoc->tenMon); ?>" disabled>
        </div> 
         <div class="form-group">
          <label for="pwd">Tên sinh viên :</label>
          <input type="text" class="form-control" id="pwd" value="<?php echo e($diem->sinhvien->tenSV); ?>" disabled>
        </div> 
        <div class="form-group">
          <label for="pwd">Điểm học phần :</label>
          <input type="number" class="form-control" id="pwd" value="<?php echo e($diem->diemhocphan); ?>" placeholder="Điểm học phần" name="diemhocphan" min="0" max="10" step="0.01">
          
          <div class="invalid-feedback">Điểm phải >= 0 và <=10 </div>
        </div>
        <div class="form-group">
          <label for="pwd">Điểm thi :</label>
          <input type="number" class="form-control" id="pwd" value="<?php echo e($diem->diemthi); ?>" placeholder="Điểm thi" name="diemthi" min="0" max="10" step="0.01">

          <div class="invalid-feedback">Điểm phải >= 0 và <=10 </div>
        </div>
        <div class="btn-setting" style="text-align: center;">
          <button type="submit" class="btn btn-primary">Sửa</button>
          <a class="btn btn-danger" href="lop/danhsach">Huỷ</a>
        </div>
      </form>
    </div>
  </div>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<script>


// Disable form submissions if there are invalid fields
(function() {
  'use strict';
  window.addEventListener('load', function() {
    var forms = document.getElementsByClassName('needs-validation');
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
</script>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QLSV_Laravel\resources\views/admin/diem/sua.blade.php ENDPATH**/ ?>